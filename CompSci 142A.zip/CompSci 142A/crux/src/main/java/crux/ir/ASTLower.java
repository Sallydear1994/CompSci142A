package crux.ir;

import com.sun.jdi.IntegerValue;
import crux.ast.SymbolTable.Symbol;
import crux.ast.*;
import crux.ast.OpExpr.Operation;
import crux.ast.traversal.NodeVisitor;
import crux.ast.types.*;
import crux.ir.insts.*;
import org.antlr.v4.runtime.atn.SemanticContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;


class InstPair
{
  private Instruction start;
  private Instruction end;
  private LocalVar value;


  InstPair(Instruction start, Instruction end, LocalVar value)
  {
    this.start = start;
    this.end = end;
    this.value = value;
    this.start.setNext(0,this.end);
  }

  InstPair(Instruction instruction, LocalVar value)
  {
    this.start = instruction;
    this.end = instruction;
    this.value = value;
  }
  InstPair(Instruction instruction)
  {
    this.start = instruction;
    this.end = instruction;
    this.value = null;
  }

  //copy constructor
  InstPair(InstPair instPair)
  {
    this.start = instPair.getStart();
    this.end = instPair.getEnd();
    this.value = instPair.getValue();
  }

  public void setValue(LocalVar value)
  {
    this.value = value;
  }
  public Instruction getStart()
  {
    return start;
  }
  public Instruction getEnd()
  {
    return end;
  }
  public LocalVar getValue()
  {
    return value;
  }

  // Implement helper method to add an edge from the end to the start of another InstPair
  // helper method to add an edge from the end to another instruction
  public void addEdge(InstPair node)
  {
    end.setNext(end.numNext(), node.getStart());
    end = node.getEnd();
  }
  public void addEdge(Instruction inst)
  {
    end.setNext(end.numNext(), inst);
    end = inst;
  }
  public void addBranch(InstPair falseBranch, InstPair trueBranch)
  {
    var newNop = new NopInst();
    falseBranch.addEdge(newNop);
    trueBranch.addEdge(newNop);
    this.end.setNext(1, trueBranch.getStart());
    this.end.setNext(0, falseBranch.getStart());
    this.end = newNop;
  }
}


/**
 * Convert AST to IR and build the CFG
 */
public final class ASTLower implements NodeVisitor<InstPair> {
  private Program mCurrentProgram = null;
  private Function mCurrentFunction = null;

  private Map<Symbol, LocalVar> mCurrentLocalVarMap = null;

  /**
   * A constructor to initialize member variables
   */
  public ASTLower() {}

  public Program lower(DeclarationList ast) {
    visit(ast);
    return mCurrentProgram;
  }

  @Override
  public InstPair visit(DeclarationList declarationList)
  {
    mCurrentProgram = new Program();
    for (int i = 0; i < declarationList.getChildren().size(); i++)
    {
      var instPair = declarationList.getChildren().get(i).accept(this);
    }
    return null;
  }

  /**
   * This visitor should create a Function instance for the functionDefinition node, add parameters
   * to the localVarMap, add the function to the program, and init the function start Instruction.
   */
  @Override
  public InstPair visit(FunctionDefinition functionDefinition)
  {
    ArrayList<LocalVar> args = new ArrayList<>();

    mCurrentFunction = new Function(functionDefinition.getSymbol().getName(), (FuncType) functionDefinition.getSymbol().getType());
    mCurrentLocalVarMap = new HashMap<Symbol, LocalVar>();

    for (int i = 0; i < functionDefinition.getParameters().size(); i++)
    {
      var parameter = functionDefinition.getParameters().get(i);
      var localVar = mCurrentFunction.getTempVar(parameter.getType(), parameter.getName());
      mCurrentLocalVarMap.put(parameter, localVar);
      args.add(localVar);
    }
    var instPair = functionDefinition.getChildren().get(0).accept(this);

    mCurrentFunction.setStart(instPair.getStart());
    mCurrentFunction.setArguments(args);
    mCurrentProgram.addFunction(mCurrentFunction);
    mCurrentFunction = null;
    mCurrentLocalVarMap = null;

    return null;
  }

  @Override
  public InstPair visit(StatementList statementList)
  {
    var instPair = new InstPair(new NopInst());

    // build the list of instPairs and link them
    for (int i = 0; i < statementList.getChildren().size(); i++)
    {
      instPair.addEdge(statementList.getChildren().get(i).accept(this));
    }
    return instPair;
  }

  /**
   * Declarations, could be either local or Global
   */
  @Override
  public InstPair visit(VariableDeclaration variableDeclaration)
  {
    if (mCurrentFunction == null)
    {
      mCurrentProgram.addGlobalVar(new GlobalDecl(variableDeclaration.getSymbol(), IntegerConstant.get(mCurrentProgram, 1)));
    }
    else
    {

      mCurrentLocalVarMap.put(variableDeclaration.getSymbol(), mCurrentFunction.getTempVar(variableDeclaration.getType(), variableDeclaration.getSymbol().getName()));
    }
    return new InstPair(new NopInst());
  }

  /**
   * Create a declaration for array and connected it to the CFG
   */
  @Override
  public InstPair visit(ArrayDeclaration arrayDeclaration)
  {
    var symbolType = (ArrayType) arrayDeclaration.getSymbol().getType();

    mCurrentProgram.addGlobalVar(new GlobalDecl(arrayDeclaration.getSymbol(), IntegerConstant.get(mCurrentProgram, symbolType.getExtent())));
    return null;
  }

  /**
   * LookUp the name in the map(s). For globals, we should do a load to get the value to load into a
   * LocalVar.
   */
  @Override
  public InstPair visit(VarAccess name)
  {
    var check = mCurrentLocalVarMap.get(name.getSymbol());
    InstPair instPair;
    if (check == null) // It is global
    {
      var addressVar = mCurrentFunction.getTempAddressVar(name.getType());
      var localVar = mCurrentFunction.getTempVar(name.getType());
      instPair = new InstPair(new AddressAt(addressVar, name.getSymbol()), new LoadInst(localVar, addressVar), localVar);
    }
    else
    {
      instPair = new InstPair(new NopInst(), check);
    }
    return instPair;
  }

  /**
   * If the location is a VarAccess to a LocalVar, copy the value to it. If the location is a
   * VarAccess to a global, store the value. If the location is ArrayAccess, store the value.
   */
  @Override
  public InstPair visit(Assignment assignment)
  {

    var location = assignment.getLocation();

    if (location.getClass() == VarAccess.class)
    {
      var locationSymbol = ((VarAccess) location).getSymbol();
      var locationType = ((VarAccess) location).getType();
      if (mCurrentLocalVarMap.get(locationSymbol) == null) // Check if varAccess is global
      {
        var rhs = assignment.getValue().accept(this);
        var addressVar = mCurrentFunction.getTempAddressVar(locationType);
        var instPair = new InstPair(new AddressAt(addressVar, locationSymbol));
        instPair.addEdge(rhs);

        instPair.addEdge(new StoreInst(rhs.getValue(), addressVar));

        return instPair;
      }
      else
      {
        var rhs = assignment.getValue().accept(this);
        var instPair = new InstPair(rhs);
        instPair.addEdge(new CopyInst(mCurrentLocalVarMap.get(locationSymbol), rhs.getValue()));
        return instPair;
      }
    }
    else if (location.getClass() == ArrayAccess.class)
    {
      var base = ((ArrayAccess) location).getBase();
      var index = ((ArrayAccess) location).getIndex();
      var type = ((ArrayAccess) location).getType();
      var indexInst = index.accept(this);
      var rhs = assignment.getValue().accept(this);
      var addressVar = mCurrentFunction.getTempAddressVar(type);
      var instPair = new InstPair(indexInst);

      instPair.addEdge(rhs);
      instPair.addEdge(new AddressAt(addressVar, base, indexInst.getValue()));
      instPair.addEdge(new StoreInst(rhs.getValue(), addressVar));
      return instPair;
    }
    return null;
  }

  /**
   * Lower a Call.
   */
  @Override
  public InstPair visit(Call call)
  {
    ArrayList<LocalVar> params = new ArrayList<>();
    var instPair = new InstPair(new NopInst());

    // Creating nodes
    for (int i = 0; i < call.getArguments().size(); i++)
    {
      //var exp = call.getArguments().get(i);
      //var instruction = exp.accept(this);
      var instruction = call.getArguments().get(i).accept(this);
      mCurrentLocalVarMap.put(call.getCallee(), instruction.getValue());
      params.add(instruction.getValue());
      instPair.addEdge(instruction);
    }
    CallInst callInst;

    //if (returnType.getClass() != VoidType.class)
    if (call.getType().getClass() != VoidType.class)
    {
      //var tempVar = mCurrentFunction.getTempVar(functionReturnType);
        var tempVar = mCurrentFunction.getTempVar(call.getType());
      callInst = new CallInst(tempVar, call.getCallee(), params);
      instPair.setValue(tempVar);
    }
    else
    {
      callInst = new CallInst(call.getCallee(), params);
    }
    instPair.addEdge(callInst);
    return instPair;
  }


  /**
   * Handle operations like arithmetics and comparisons. Also handle logical operations (and,
   * or, not).
   */
  @Override
  public InstPair visit(OpExpr operation)
  {
    var destVar = mCurrentFunction.getTempVar(operation.getType());
    if (operation.getRight() != null)
    {
        var left = operation.getLeft().accept(this);
        var right = operation.getRight().accept(this);

        if (operation.getOp().equals(Operation.ADD))
        {
            var instPair = new InstPair(left);
            instPair.addEdge(right);
            instPair.setValue(destVar);
            //binOp = new BinaryOperator(BinaryOperator.Op.Add, destVar, left.getValue(), right.getValue());
            //instPair.addEdge(binOp);
            instPair.addEdge(new BinaryOperator(BinaryOperator.Op.Add, destVar, left.getValue(), right.getValue()));
            return instPair;
        }
        else if (operation.getOp().equals(Operation.SUB))
        {
            var instPair = new InstPair(left);
            instPair.addEdge(right);
            instPair.setValue(destVar);
            instPair.addEdge(new BinaryOperator(BinaryOperator.Op.Sub, destVar, left.getValue(), right.getValue()));
            return instPair;
        }
        else if (operation.getOp().equals(Operation.MULT))
        {
            var instPair = new InstPair(left);
            instPair.addEdge(right);
            instPair.setValue(destVar);
            instPair.addEdge(new BinaryOperator(BinaryOperator.Op.Mul, destVar, left.getValue(), right.getValue()));
            return instPair;
        }
        else if (operation.getOp().equals(Operation.DIV))
        {
            var instPair = new InstPair(left);
            instPair.addEdge(right);
            instPair.setValue(destVar);
            instPair.addEdge(new BinaryOperator(BinaryOperator.Op.Div, destVar, left.getValue(), right.getValue()));
            return instPair;
        }
        else if (operation.getOp().equals(Operation.LT))
        {
            var instPair = new InstPair(left);
            instPair.addEdge(right);
            instPair.setValue(destVar);
            instPair.addEdge(new CompareInst(destVar, CompareInst.Predicate.LT, left.getValue(), right.getValue()));
            return instPair;
        }
        else if (operation.getOp().equals(Operation.EQ))
        {
            var instPair = new InstPair(left);
            instPair.addEdge(right);
            instPair.setValue(destVar);
            //compareInst = new CompareInst(destVar, CompareInst.Predicate.EQ, left.getValue(), right.getValue());
            //instPair.addEdge(compareInst);
            instPair.addEdge(new CompareInst(destVar, CompareInst.Predicate.EQ, left.getValue(), right.getValue()));
            return instPair;
        }
        else if (operation.getOp().equals(Operation.GT))
        {
            var instPair = new InstPair(left);
            instPair.addEdge(right);
            instPair.setValue(destVar);
            //compareInst = new CompareInst(destVar, CompareInst.Predicate.GT, left.getValue(), right.getValue());
            //instPair.addEdge(compareInst);
            instPair.addEdge(new CompareInst(destVar, CompareInst.Predicate.GT, left.getValue(), right.getValue()));
            return instPair;
        }
        else if (operation.getOp().equals(Operation.LE))
        {
            var instPair = new InstPair(left);
            instPair.addEdge(right);
            instPair.setValue(destVar);
            instPair.addEdge(new CompareInst(destVar, CompareInst.Predicate.LE, left.getValue(), right.getValue()));
            return instPair;
        }
        else if (operation.getOp().equals(Operation.NE))
        {
            var instPair = new InstPair(left);
            instPair.addEdge(right);
            instPair.setValue(destVar);
            instPair.addEdge(new CompareInst(destVar, CompareInst.Predicate.NE, left.getValue(), right.getValue()));
            return instPair;
        }
        else if (operation.getOp().equals(Operation.GE))
        {
            var instPair = new InstPair(left);
            instPair.addEdge(right);
            instPair.setValue(destVar);
            instPair.addEdge(new CompareInst(destVar, CompareInst.Predicate.GE, left.getValue(), right.getValue()));
            return instPair;
        }
        else if (operation.getOp().equals(Operation.LOGIC_OR))
        {
            left.addEdge(new JumpInst(left.getValue()));
            right.addEdge(new CopyInst(destVar, right.getValue()));
            left.addBranch(right, new InstPair(new CopyInst(destVar, left.getValue())));
            var instPair = new InstPair(left);
            instPair.setValue(destVar);
            return instPair;
        }
        else if (operation.getOp().equals(Operation.LOGIC_AND))
        {
            //var jump = new JumpInst(left.getValue());
            //var falseCopy = new CopyInst(destVar, left.getValue());
            //var trueCopy = new CopyInst(destVar, right.getValue());
            //left.addEdge(jump);
            left.addEdge(new JumpInst(left.getValue()));
            //right.addEdge(trueCopy);
            right.addEdge(new CopyInst(destVar, right.getValue()));
            //left.addBranch(new InstPair(falseCopy), right);
            left.addBranch(new InstPair(new CopyInst(destVar, left.getValue())), right);
            var instPair = new InstPair(left);
            instPair.setValue(destVar);
            return instPair;
        }
        else
        {
            System.out.println("Unknown Symbol!!");
        }
    }
    else // For Logical NOT
    {
        var left = operation.getLeft().accept(this);
        //var not = new UnaryNotInst(destVar, left.getValue());
        //var instPair = new InstPair(left);
        var instPair = new InstPair(left);
        //instPair.addEdge(not);
        instPair.addEdge(new UnaryNotInst(destVar, left.getValue()));
        instPair.setValue(destVar);
        return instPair;
    }
    return null;
  }


  private InstPair visit(Expression expression)
  {
      System.out.println("Why did I never have to visit this?");
    return null;
  }

  /**
   * It should compute the address into the array, do the load, and return the value in a LocalVar.
   */
  @Override
  public InstPair visit(ArrayAccess access)
  {
    var index = access.getIndex().accept(this);
    var addressVar = mCurrentFunction.getTempAddressVar(access.getType());
    var destVar = mCurrentFunction.getTempVar(access.getType());
    var instPair = new InstPair(index);

    instPair.addEdge(new AddressAt(addressVar, access.getBase(), index.getValue()));
    instPair.addEdge(new LoadInst(destVar, addressVar));
    instPair.setValue(destVar);

    return instPair;
    //return null;
  }

  /**
   * Copy the literal into a tempVar
   */
  @Override
  public InstPair visit(LiteralBool literalBool)
  {
    var localVar = mCurrentFunction.getTempVar(literalBool.getType());

    return new InstPair(new CopyInst(localVar, BooleanConstant.get(mCurrentProgram, literalBool.getValue())), localVar);
  }

  /**
   * Copy the literal into a tempVar
   */
  @Override
  public InstPair visit(LiteralInt literalInt)
  {
    var localVar = mCurrentFunction.getTempVar(literalInt.getType());
    return new InstPair(new CopyInst(localVar, IntegerConstant.get(mCurrentProgram, literalInt.getValue())), localVar);
  }

  /**
   * Lower a Return.
   */
  @Override
  public InstPair visit(Return ret)
  {
    var instPair = ret.getValue().accept(this);

    instPair.addEdge(new ReturnInst(instPair.getValue()));
    return instPair;
  }

  /**
   * Break Node
   */
  @Override
  public InstPair visit(Break brk)
  {
    return new InstPair(new NopInst());
  }

  /**
   * Implement If Then Else statements.
   */
  @Override
  public InstPair visit(IfElseBranch ifElseBranch)
  {
    var condition = ifElseBranch.getCondition().accept(this);
    var elseBlock = ifElseBranch.getElseBlock().accept(this);
    var thenBlock = ifElseBranch.getThenBlock().accept(this);
    var instPair = new InstPair(condition);

    instPair.addEdge(new JumpInst(condition.getValue()));
    instPair.addBranch(elseBlock, thenBlock);
    return instPair;
  }

  /**
   * Implement for loops.
   */
  @Override
  public InstPair visit(For loop)
  {

    var init = loop.getInit().accept(this);
    var condition = loop.getCond().accept(this);
    var increment = loop.getIncrement().accept(this);
    var body = loop.getBody().accept(this);

    condition.addEdge(new JumpInst(condition.getValue()));
    increment.addEdge(condition);
    body.addEdge(increment);
    condition.addBranch(new InstPair(new NopInst()), body);
    var instPair = new InstPair(init);
    instPair.addEdge(condition);
    return instPair;
  }
}
