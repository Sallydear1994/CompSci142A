package crux.ast;

public interface Expression extends Node {
}
