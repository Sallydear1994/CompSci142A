package crux.ast;

public interface Declaration extends Node {
}
