package crux.ast.types;

import crux.ast.SymbolTable.Symbol;
import crux.ast.*;
import crux.ast.traversal.NullNodeVisitor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * This class will associate types with the AST nodes from Stage 2
 */
public final class TypeChecker {
  private final ArrayList<String> errors = new ArrayList<>();
  public boolean lastStatementReturns; // Check functions returns for non-voids and unreachable statements
  public Symbol currentFunctionSymbol; // Check if return type is concurrent

  public ArrayList<String> getErrors() {
    return errors;
  }

  public void check(DeclarationList ast) {
    var inferenceVisitor = new TypeInferenceVisitor();
    inferenceVisitor.visit(ast);
  }

  /**
   * Helper function, should be used to add error into the errors array
   */
  private void addTypeError(Node n, String message) {
    errors.add(String.format("TypeError%s[%s]", n.getPosition(), message));
  }

  /**
   * Helper function, should be used to record Types if the Type is an ErrorType then it will call
   * addTypeError
   */
  private void setNodeType(Node n, Type ty) {
    ((BaseNode) n).setType(ty);
    if (ty.getClass() == ErrorType.class) {
      var error = (ErrorType) ty;
      addTypeError(n, error.getMessage());
    }
  }

  /**
   * Helper to retrieve Type from the map
   */
  public Type getType(Node n) {
    return ((BaseNode) n).getType();
  }


  /**
   * This calls will visit each AST node and try to resolve it's type with the help of the
   * symbolTable.
   */
  private final class TypeInferenceVisitor extends NullNodeVisitor<Void> {
    @Override
    public Void visit(VarAccess vaccess)
    {
      setNodeType(vaccess, vaccess.getSymbol().getType());
      return null;
    }

    @Override
    public Void visit(ArrayDeclaration arrayDeclaration)
    {
      setNodeType(arrayDeclaration, arrayDeclaration.getSymbol().getType());
      lastStatementReturns = false;
      return null;
    }

    @Override
    public Void visit(Assignment assignment)
    {
      for (int i = 0; i < assignment.getChildren().size(); i++)
      {
        assignment.getChildren().get(i).accept(this);
      }
      var location = (BaseNode) assignment.getLocation();
      var locationType = location.getType();
      var value = (BaseNode) assignment.getValue();
      var valueType = value.getType();
      var nodeType = locationType.assign(valueType);
      setNodeType(assignment, nodeType);
      return null;
    }

    @Override
    public Void visit(Break brk)
    {
      lastStatementReturns = false;
      return null;
    }

    @Override
    public Void visit(Call call)
    {
      for (int i = 0; i < call.getChildren().size(); i++)
      {
        call.getChildren().get(i).accept(this);
      }
      FuncType calleeType = (FuncType) call.getCallee().getType();
      var returnType = calleeType.call(calleeType.getArgs());
      setNodeType(call, returnType);

      // Update last statement returns
      return null;
    }

    @Override
    public Void visit(DeclarationList declarationList)
    {
      for (int i = 0; i < declarationList.getChildren().size(); i++)
      {
        declarationList.getChildren().get(i).accept(this);
      }
      return null;
    }

    @Override
    public Void visit(FunctionDefinition functionDefinition)
    {
      currentFunctionSymbol = functionDefinition.getSymbol();
      for (int i = 0; i < functionDefinition.getChildren().size(); i++)
      {
        functionDefinition.getChildren().get(i).accept(this);
      }
      return null;
    }

    @Override
    public Void visit(IfElseBranch ifElseBranch)
    {
      ifElseBranch.getCondition().accept(this);
      ifElseBranch.getThenBlock().accept(this);
      ifElseBranch.getElseBlock().accept(this);
      return null;
    }

    @Override
    public Void visit(ArrayAccess access)
    {
      access.getChildren().get(0).accept(this);
      var base = access.getBase();
      var baseType = base.getType();
      var offset = (BaseNode) access.getChildren().get(0);
      var type = baseType.index(offset.getType());
      setNodeType(access, type);
      return null;
    }

    @Override
    public Void visit(LiteralBool literalBool)
    {
      setNodeType(literalBool, new BoolType());
      return null;
    }

    @Override
    public Void visit(LiteralInt literalInt)
    {
      setNodeType(literalInt, new IntType());
      return null;
    }

    @Override
    public Void visit(For forloop)
    {
      forloop.getCond().accept(this);
      forloop.getInit().accept(this);
      forloop.getBody().accept(this);
      forloop.getIncrement().accept(this);
      return null;
    }

    @Override
    public Void visit(OpExpr op)
    {
      var left = op.getLeft();
      var right = op.getRight();

      left.accept(this);
      if (right == null)
      {
        var leftType = (BoolType) getType(left);
        setNodeType(op, leftType.not(null));
      }
      else
      {
        right.accept(this);
        if (op.getOp().equals(OpExpr.Operation.ADD))
        {
          setNodeType(op, getType(left).add(getType(right)));
        }
        else if (op.getOp().equals(OpExpr.Operation.SUB))
        {
          setNodeType(op, getType(left).sub(getType(right)));
        }
        else if (op.getOp().equals(OpExpr.Operation.MULT))
        {
          setNodeType(op, getType(left).mul(getType(right)));
        }
        else if (op.getOp().equals(OpExpr.Operation.DIV))
        {
          setNodeType(op, getType(left).div(getType(right)));
        }
        else if (op.getOp().equals(OpExpr.Operation.LT))
        {
          setNodeType(op, getType(left).compare(getType(right)));
        }
        else if (op.getOp().equals(OpExpr.Operation.GT))
        {
          setNodeType(op, getType(left).compare(getType(right)));
        }
        else if (op.getOp().equals(OpExpr.Operation.LE))
        {
          setNodeType(op, getType(left).compare(getType(right)));
        }
        else if (op.getOp().equals(OpExpr.Operation.EQ))
        {
          setNodeType(op, getType(left).compare(getType(right)));
        }
        else if (op.getOp().equals(OpExpr.Operation.NE))
        {
          setNodeType(op, getType(left).compare(getType(right)));
        }
        else if (op.getOp().equals(OpExpr.Operation.GE))
        {
          setNodeType(op, getType(left).compare(getType(right)));
        }
        else if (op.getOp().equals(OpExpr.Operation.LOGIC_OR))
        {
          setNodeType(op, getType(left).or(getType(right)));
        }
        else if (op.getOp().equals(OpExpr.Operation.LOGIC_AND))
        {
          setNodeType(op, getType(left).and(getType(right)));
        }
      }
      return null;
    }

    @Override
    public Void visit(Return ret)
    {
      ret.getValue().accept(this);
      lastStatementReturns = true;
      return null;
    }

    @Override
    public Void visit(StatementList statementList)
    {
      for (int i = 0; i < statementList.getChildren().size(); i++)
      {
        statementList.getChildren().get(i).accept(this);
      }
      return null;
    }

    @Override
    public Void visit(VariableDeclaration variableDeclaration)
    {
      setNodeType(variableDeclaration, variableDeclaration.getSymbol().getType());
      lastStatementReturns = false;
      return null;
    }
  }
}
