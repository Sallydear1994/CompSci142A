package crux.ast.types;

/**
 * Types for Booleans values This should implement the equivalent methods along with and,or, and not
 * equivalent will check if the param is instance of BoolType
 */
public final class BoolType extends Type implements java.io.Serializable {
  static final long serialVersionUID = 12022L;

  @Override
  public String toString() {
    return "bool";
  }

  public boolean equivalent(Type that)
  {
    return that.getClass() == BoolType.class;
  }

  public Type and(Type that)
  {
    if (this.equivalent(that))
    {
      return new BoolType();
    }
    else
    {
      return super.and(that);
    }
  }

  public Type or(Type that)
  {
    if (this.equivalent(that))
    {
      return new BoolType();
    }
    else
    {
      return super.or(that);
    }
  }

  public Type not(Type that)
  {
    if (that == null)
    {
      return new BoolType();
    }
    else
    {
      return super.not();
    }
  }

  public Type assign(Type source)
  {
    if (this.equivalent(source))
    {
      return new VoidType();
    }
    else
    {
      return super.assign(source);
    }
  }
}
