package crux.ast;

public interface Statement extends Node {
}
