package crux.backend;

import crux.ast.SymbolTable.Symbol;
import crux.ast.types.ArrayType;
import crux.ast.types.FuncType;
import crux.ast.types.IntType;
import crux.ast.types.VoidType;
import crux.ir.*;
import crux.ir.insts.*;
import crux.printing.IRValueFormatter;

import java.util.*;

/**
 * Convert the CFG into Assembly Instructions
 */
public final class CodeGen extends InstVisitor {
  private final Program p;
  private final CodePrinter out;

  // User added
  private HashMap<Variable, Integer> varIndexMap; // for stack
  private Stack<Instruction> visitStack;
  private Set<Instruction> visitedSet;
  private int varIndex;
  private HashMap<Instruction, String> labels;

  public CodeGen(Program p) {
    this.p = p;
    // Do not change the file name that is outputted or it will
    // break the grader!

    out = new CodePrinter("a.s");
  }


  private void genCode(Function f, int count[])
  {
    // 1. Assign labels to jump targets
    labels = f.assignLabels(count);

    // 2. Declare function and label
    out.printCode(".globl " + f.getName());
    out.printLabel(f.getName() + ":");

    varIndex = 1;

    // 3.Print prologue such that stack is 16 byte aligned
    var numSlots = f.getNumTempVars() + f.getNumTempAddressVars();
    if (numSlots % 2 != 0)
    {
      numSlots++;
    }
    out.printCode("enter $(8 * " + numSlots + "), $0");

    // 4. Move arguments from registers to local variable
    if (f.getArguments().size() > 0) // For 1st arg (%rdi)
    {
      out.printCode("movq %rdi, " + -8 * varIndex + "(%rbp)");
      varIndexMap.put(f.getArguments().get(0), -8 * varIndex);
      varIndex++;
      if (f.getArguments().size() > 1) // For 2nd arg (%rsi)
      {
        out.printCode("movq %rsi, " + -8 * varIndex + "(%rbp)");
        varIndexMap.put(f.getArguments().get(1), -8 * varIndex);
        varIndex++;
        if (f.getArguments().size() > 2) // For 3rd arg (%rdx)
        {
          out.printCode("movq %rdx, " + -8 * varIndex + "(%rbp)");
          varIndexMap.put(f.getArguments().get(2), -8 * varIndex);
          varIndex++;
          if (f.getArguments().size() > 3) // For 4th arg (%rcx)
          {
            out.printCode("movq %rcx, " + -8 * varIndex + "(%rbp)");
            varIndexMap.put(f.getArguments().get(3), -8 * varIndex);
            varIndex++;
            if (f.getArguments().size() > 4) // For 5th arg (%r8)
            {
              out.printCode("movq %r8, " + -8 * varIndex + "(%rbp)");
              varIndexMap.put(f.getArguments().get(4), -8 * varIndex);
              varIndex++;
              if (f.getArguments().size() > 5) // for 6th arg (%r9)
              {
                out.printCode("movq %r9, " + -8 * varIndex + "(%rbp)");
                varIndexMap.put(f.getArguments().get(5), -8 * varIndex);
                varIndex++;
                if (f.getArguments().size() > 6) // for 7th arg and more
                {
                  int argN = f.getArguments().size() - 7 ;
                  for (int i = 6; i < f.getArguments().size(); i++)
                  {
                    out.printCode("movq " + (8 * argN + 16 + 8) + "(%rbp), %r10");
                    out.printCode("movq %r10, " + -8 * varIndex + "(%rbp)");
                    varIndexMap.put(f.getArguments().get(i), -8 * varIndex);
                    varIndex++;
                    argN--;
                  }
                }
              }
            }
          }
        }
      }
    }

    // 5. Generate code for function body
    visitStack.push(f.getStart());
    while (visitStack.size() > 0)
    {
      var node = visitStack.pop();
      if (visitedSet.contains(node))
      {
        out.printCode("jmp " + labels.get(node));
      }
      else
      {
        // if instruction is a jump target print out its label
        if (labels.get(node) != null)
        {
          out.printLabel(labels.get(node) + ":");
        }

        // Visit the instruction to print out asm instructions
        node.accept(this);
        visitedSet.add(node);

        // If there are instructions that come next, push them to stack
        if (node.numNext() > 0)
        {
          if (node.numNext() == 2)
          {
            visitStack.push(node.getNext(1));
            visitStack.push(node.getNext(0));
          }
          else
          {
            visitStack.push(node.getNext(0));
          }
        }
        else
        {
          // 6. Print epilogue
          out.printCode("leave");
          out.printCode("ret");
        }
      }
    }

  }

  /**
   * It should allocate space for globals call genCode for each Function
   */
  public void genCode() {
      // ToDo

    for (Iterator<GlobalDecl> glob_it = p.getGlobals(); glob_it.hasNext();)
    {
        GlobalDecl g = glob_it.next();
        var name = g.getSymbol().getName();
        int size;
        if (g.getSymbol().getType().getClass() == ArrayType.class)
        {
          var type = (ArrayType) g.getSymbol().getType();
          size = 8 * (int)type.getExtent();
        }
        else
        {
          size = 8;
        }
        out.printCode(".comm " + name + ", " + size + ", 8");
    }

    int count[] = new int[1];
    visitStack = new Stack<>();
    visitedSet = new LinkedHashSet<Instruction>();

    varIndexMap = new HashMap<>();

    for (Iterator<Function> func_it = p.getFunctions(); func_it.hasNext();)
    {
      Function f = func_it.next();
      genCode(f, count);
      varIndexMap.clear();
    }

    out.close();
  }

  public void visit(AddressAt i)
  {
    out.printCode("/* AddressAt */");
    out.printCode("movq " + i.getBase().getName() + "@GOTPCREL(%rip), %r11");
    if (i.getOffset() != null)
    {
      out.printCode("movq " + varIndexMap.get(i.getOffset()) + "(%rbp), %r10");
      out.printCode("imulq $8, %r10");
      out.printCode("addq %r10, %r11");
    }
    out.printCode("movq %r11, " + -8 * varIndex + "(%rbp)");
    varIndexMap.put(i.getDst(), -8 * varIndex);
    varIndex++;
  }

  public void visit(BinaryOperator i)
  {
    out.printCode("/* BinaryOperator: */");
    var left = i.getLeftOperand();
    var right = i.getRightOperand();
    if (i.getOperator().equals(BinaryOperator.Op.Add))
    {
      out.printCode("movq " + varIndexMap.get(left) + "(%rbp), %r10");
      out.printCode("addq " + varIndexMap.get(right) + "(%rbp), %r10");
      out.printCode("movq %r10, " + -8 * varIndex + "(%rbp)");
    }
    else if (i.getOperator().equals(BinaryOperator.Op.Sub))
    {
      out.printCode("movq " + varIndexMap.get(left) + "(%rbp), %r10");
      out.printCode("subq " + varIndexMap.get(right) + "(%rbp), %r10");
      out.printCode("movq %r10, " + -8 * varIndex + "(%rbp)");
    }
    else if (i.getOperator().equals(BinaryOperator.Op.Mul))
    {
      out.printCode("movq " + varIndexMap.get(left) + "(%rbp), %r10");
      out.printCode("imulq " + varIndexMap.get(right) + "(%rbp), %r10");
      out.printCode("movq %r10, " + -8 * varIndex + "(%rbp)");
    }
    else if (i.getOperator().equals(BinaryOperator.Op.Div))
    {
      out.printCode("movq " + varIndexMap.get(left) + "(%rbp), %rax");
      out.printCode("cqto");
      out.printCode("idivq " + varIndexMap.get(right) + "(%rbp)");
      out.printCode("movq %rax, " + -8 * varIndex + "(%rbp)");
    }
    varIndexMap.put(i.getDst(), -8 * varIndex);
    varIndex++;
  }

  public void visit(CompareInst i)
  {
    out.printCode("/* CompareInst */");
    if (i.getPredicate().equals(CompareInst.Predicate.GT))
    {
      out.printCode("movq $0, %rax");
      out.printCode("movq $1, %r10");
      out.printCode("movq " + varIndexMap.get(i.getLeftOperand()) + "(%rbp), %r11");
      out.printCode("cmp " + varIndexMap.get(i.getRightOperand()) + "(%rbp), %r11");
      out.printCode("cmovg %r10, %rax");
      out.printCode("movq %rax, " + -8 * varIndex + "(%rbp)");
    }
    else if (i.getPredicate().equals(CompareInst.Predicate.LT))
    {
      out.printCode("movq $0, %rax");
      out.printCode("movq $1, %r10");
      out.printCode("movq " + varIndexMap.get(i.getLeftOperand()) + "(%rbp), %r11");
      out.printCode("cmp " + varIndexMap.get(i.getRightOperand()) + "(%rbp), %r11");
      out.printCode("cmovl %r10, %rax");
      out.printCode("movq %rax, " + -8 * varIndex + "(%rbp)");
    }
    else if (i.getPredicate().equals(CompareInst.Predicate.LE))
    {
      out.printCode("movq $0, %rax");
      out.printCode("movq $1, %r10");
      out.printCode("movq " + varIndexMap.get(i.getLeftOperand()) + "(%rbp), %r11");
      out.printCode("cmp " + varIndexMap.get(i.getRightOperand()) + "(%rbp), %r11");
      out.printCode("cmovle %r10, %rax");
      out.printCode("movq %rax, " + -8 * varIndex + "(%rbp)");
    }
    else if (i.getPredicate().equals(CompareInst.Predicate.GE))
    {
      out.printCode("movq $0, %rax");
      out.printCode("movq $1, %r10");
      out.printCode("movq " + varIndexMap.get(i.getLeftOperand()) + "(%rbp), %r11");
      out.printCode("cmp " + varIndexMap.get(i.getRightOperand()) + "(%rbp), %r11");
      out.printCode("cmovge %r10, %rax");
      out.printCode("movq %rax, " + -8 * varIndex + "(%rbp)");
    }
    else if (i.getPredicate().equals(CompareInst.Predicate.EQ))
    {
      out.printCode("movq $0, %rax");
      out.printCode("movq $1, %r10");
      out.printCode("movq " + varIndexMap.get(i.getLeftOperand()) + "(%rbp), %r11");
      out.printCode("cmp " + varIndexMap.get(i.getRightOperand()) + "(%rbp), %r11");
      out.printCode("cmove %r10, %rax");
      out.printCode("movq %rax, " + -8 * varIndex + "(%rbp)");
    }
    else if (i.getPredicate().equals(CompareInst.Predicate.NE))
    {
      out.printCode("movq $0, %rax");
      out.printCode("movq $1, %r10");
      out.printCode("movq " + varIndexMap.get(i.getLeftOperand()) + "(%rbp), %r11");
      out.printCode("cmp " + varIndexMap.get(i.getRightOperand()) + "(%rbp), %r11");
      out.printCode("cmovne %r10, %rax");
      out.printCode("movq %rax, " + -8 * varIndex + "(%rbp)");
    }
    varIndexMap.put(i.getDst(), -8 * varIndex);
    varIndex++;
  }

  public void visit(CopyInst i)
  {
    out.printCode("/* CopyInst: */");
    if (i.getSrcValue().getClass() == IntegerConstant.class)
    {
      var intConstant = (IntegerConstant) i.getSrcValue();
      out.printCode("movq $" + intConstant.getValue() + ", %r10");
    }
    else if (i.getSrcValue().getClass() == BooleanConstant.class)
    {
      var boolConstant = (BooleanConstant) i.getSrcValue();
      if (boolConstant.getValue())
      {
        out.printCode("movq $1, %r10");
      }
      else
      {
        out.printCode("movq $0, %r10");
      }
    }
    else
    {
      out.printCode("movq " + varIndexMap.get(i.getSrcValue()) + "(%rbp), %r10");
    }

    if (varIndexMap.get(i.getDstVar()) == null)
    {
      varIndexMap.put(i.getDstVar(), -8 * varIndex);
      out.printCode("movq %r10, " + varIndexMap.get(i.getDstVar()) + "(%rbp)");
      varIndex++;
    }
    else
    {
      out.printCode("movq %r10, " + varIndexMap.get(i.getDstVar()) + "(%rbp)");
    }
  }

  public void visit(JumpInst i)
  {
    out.printCode("/* JumpInst: */");
    out.printCode("movq " + varIndexMap.get(i.getPredicate()) + "(%rbp), %r10");
    out.printCode("cmp $1, %r10");
    out.printCode("je " + labels.get(i.getNext(1)));
  }

  public void visit(LoadInst i)
  {
    out.printCode("/* LoadInst: */");
    out.printCode("movq " + varIndexMap.get(i.getSrcAddress()) + "(%rbp), %r11");
    out.printCode("movq 0(%r11), %r10");
    out.printCode("movq %r10, " + -8 * varIndex + "(%rbp)");
    varIndexMap.put(i.getDst(), -8 * varIndex);
    varIndex++;
  }

  public void visit(NopInst i)
  {
  }

  public void visit(StoreInst i)
  {
    out.printCode("/* StoreInst: */");
    out.printCode("movq " + varIndexMap.get(i.getSrcValue()) + "(%rbp), %r10");
    out.printCode("movq " + varIndexMap.get(i.getDestAddress()) + "(%rbp), %r11");
    out.printCode("movq %r10, 0(%r11)");
  }

  public void visit(ReturnInst i)
  {
    out.printCode("/* Return: */");
    out.printCode("movq " + varIndexMap.get(i.getReturnValue()) + "(%rbp), %rax");
    out.printCode("leave");
    out.printCode("ret");
  }

  public void visit(CallInst i)
  {
    out.printCode("/* CallInst: */");
    var name = i.getCallee().getName();

    // Store the parameters
    if (i.getParams().size() > 0) // 1st arg (%rdi)
    {
      out.printCode("movq " + varIndexMap.get(i.getParams().get(0)) + "(%rbp), %rdi");
      if (i.getParams().size() > 1) // 2nd arg (%rsi)
      {
        out.printCode("movq " + varIndexMap.get(i.getParams().get(1)) + "(%rbp), %rsi");
        if (i.getParams().size() > 2) // 3rd arg (%rdx)
        {
          out.printCode("movq " + varIndexMap.get(i.getParams().get(2)) + "(%rbp), %rdx");
          if (i.getParams().size() > 3) // 4th arg (%rcx)
          {
            out.printCode("movq " + varIndexMap.get(i.getParams().get(3)) + "(%rbp), %rcx");
            if (i.getParams().size() > 4) // 5th arg (%r8)
            {
              out.printCode("movq " + varIndexMap.get(i.getParams().get(4)) + "(%rbp), %r8");
              if (i.getParams().size() > 5) // 6th arg (%r9)
              {
                out.printCode("movq " + varIndexMap.get(i.getParams().get(5)) + "(%rbp), %r9");
                if (i.getParams().size() > 6) // 7th and above arg
                {
                  int n = 0;
                  for (int j = 6; j < i.getParams().size(); j++)
                  {
                    out.printCode("movq " + varIndexMap.get(i.getParams().get(j)) + "(%rbp), %r10");
                    out.printCode("movq %r10, " + (8 * n + 16) + "(%rbp)");
                    n++;
                  }
                }
              }
            }
          }
        }
      }
    }

    var functionType = (FuncType)i.getCallee().getType();
    var returnType = functionType.getRet();
    out.printCode("call " + name);
    if (!returnType.getClass().equals(VoidType.class))
    {
      out.printCode("movq %rax, " + -8 * varIndex + "(%rbp)");
      varIndexMap.put(i.getDst(), -8 * varIndex);
      varIndex++;
    }
    if (i.getParams().size() > 6)
    {
      out.printCode("addq $" + (8 * (i.getParams().size() - 6)) + ", %rsp");
    }
  }

  public void visit(UnaryNotInst i)
  {
    out.printCode("/* UnaryNotInst */");
    out.printCode("movq " + varIndexMap.get(i.getInner()) + "(%rbp)" + ", %r10");
    out.printCode("movq $1, %r11");
    out.printCode("subq %r10, %r11");
    out.printCode("movq %r11, " + -8 * varIndex + "(%rbp)");
    varIndexMap.put(i.getDst(), -8 * varIndex);
    varIndex++;
  }
}
